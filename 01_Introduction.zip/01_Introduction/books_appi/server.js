const { Router } = require('express');
const router = new Router();

let books = [];
let nextId = 1;

router.get('/books', (req, res) => {
    if (books.length === 0) {
        return res.json({ message: "no books found" });
    } else {
        return res.json(books);
    }
});

router.get('/books/:id', (req, res) => {
    const bookid = parseInt(req.params.id);
    let foundbook = null;
    for (let i = 0; i < books.length; i++) {
        const currentbook = books[i];
        if (currentbook.id === bookid) {
            foundbook = currentbook;
            break;
        }
    }
    if (foundbook) {
        return res.json(foundbook);
    } else {
        return res.status(404).json({ message: "Book not found" });
    }
});

router.post('/books', (req, res) => {
    const bookTitle = req.body.title;
    const bookAuthor = req.body.author;
    const bookISBN = req.body.isbn; 

    if (!bookTitle || !bookAuthor || !bookISBN) {
        return res.status(400).json({ message: "Missing required fields: title, author, isbn" });
    }

    const newbook = {
        id: nextId,
        title: bookTitle,
        author: bookAuthor,
        isbn: bookISBN 
    };
    books.push(newbook);
    nextId++;
    return res.status(201).json(newbook);
});

router.put('/books/:id', (req, res) => {
    const bookIdToUpdate = parseInt(req.params.id);
    const newTitle = req.body.title;
    const newAuthor = req.body.author;
    const newISBN = req.body.isbn; 

    let foundBookIndex = -1;
    for (let i = 0; i < books.length; i++) {
        if (books[i].id === bookIdToUpdate) {
            foundBookIndex = i;
            break;
        }
    }
    if (foundBookIndex === -1) {
        return res.status(404).json({ message: "Book not found" });
    }
    const bookToUpdate = books[foundBookIndex];
    if (newTitle !== undefined) {
        bookToUpdate.title = newTitle;
    }
    if (newAuthor !== undefined) {
        bookToUpdate.author = newAuthor;
    }
    
    if (newISBN !== undefined) {
        bookToUpdate.isbn = newISBN; 
    }
    return res.status(200).json(bookToUpdate);
});

router.delete('/books/:id', (req, res) => {
    const booktodelete = parseInt(req.params.id);
    let foundBookIndex = -1;
    for (let i = 0; i < books.length; i++) {
        if (books[i].id === booktodelete) {
            foundBookIndex = i;
            break;
        }
    }
    if (foundBookIndex === -1) {
        return res.status(404).json({ message: "Book not found" });
    }
    books.splice(foundBookIndex, 1); 
    return res.status(200).json({ message: "deleted" });
});

module.exports = router;