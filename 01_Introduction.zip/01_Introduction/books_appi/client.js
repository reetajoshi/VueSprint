const axios = require('axios');

const http = axios.create({
    baseURL: "http://localhost:3000"
})
const AUTH_TOKEN = "your_secret_api_key_123"; 
http.interceptors.request.use(config => {
    config.headers.Authorization = AUTH_TOKEN;
    return config;
}, error => {
    return Promise.reject(error);
});

const validateBookList = () => {
    /**
     * we're expecting server to send us
     * {
     *     "message": "no books found"
     * }
     * @returns {Promise<boolean>}
     */
    const noBookFound = async () => {
        const response = await http.get('/books').catch((err) => ({data: {}}));
        if (response.data.message === "no books found") {
            console.log('[PASS] noBookFound')
        } else {
            console.log('[FAIL] noBookFound - Expected "no books found", got:', response.data) 
        }
    }
    /**
     * we're expecting server to send an array
     * @returns {Promise<*>}
     */
    const bookList = async () => {
        const response = await http.get('/books').catch((err) => ({data: null}));
        if (Array.isArray(response.data) && response.data.length) {
            console.log('[PASS] bookList')
        } else {
            console.log('[FAIL] bookList - Expected array with content, got:', response.data) 
        }
    }

    const bookCreate = async () => {
        const book = {
            title: "Lost City",
            author: "Anuj",
            isbn: "978-1234567891" // <--- CRUCIAL CHANGE: ADDED ISBN HERE!
        }
        /**
         * return {
         *     id: // counter,
         *     title,
         *     author,
         * isbn // Expected in response now
         * }
         * @type {Promise<axios.AxiosResponse<any> | {data: null}>}
         */
        const res = await http.post('/books', book).catch((err) => ({data: null, status: err.response?.status})) 
        if (!res.data || !res.data.id) {
            console.log('[FAIL] bookCreate - No data or ID. Status:', res.status, 'Data:', res.data) 
            return;
        }
        
        if (res.data.title !== book.title || res.data.author !== book.author || res.data.isbn !== book.isbn) { 
            console.log('[FAIL] bookCreate - Data mismatch. Expected:', book, 'Got:', res.data)
            return;
        }
        console.log('[PASS] bookCreate')
        return res.data;
    }

    const deleteBook = async (id) => {
        const response = await http.delete(`/books/${id}`).catch((err) => ({data: {message: null}, status: err.response?.status})) // Added status
        if (response.data.message === "deleted") {
            console.log('[PASS] deleteBook')
        } else {
            console.log('[FAIL] deleteBook - Expected "deleted", got:', response.data, 'Status:', response.status) // More detail
        }
    }

    const updateBook = async (id, title) => {
        const response = await http.put(`/books/${id}`, {title}).catch((err) => ({data: {message: null}, status: err.response?.status})) // Added status
        if (response.data.title !== title) {
            console.log('[FAIL] updateBook - Title mismatch. Expected:', title, 'Got:', response.data, 'Status:', response.status) // More detail
            return;
        }
        console.log('[PASS] updateBook')
    }

    const getBookNotFound = async () => {
        const id = 9999; 
        try {
            await http.get(`/books/${id}`);
            console.log('[FAIL] getBookNotFound - Expected 404, but got success');
        } catch (error) {
            if (error.response && error.response.status === 404 && error.response.data.message === "Book not found") {
                console.log('[PASS] getBookNotFound');
            } else {
                console.log('[FAIL] getBookNotFound - Unexpected error response:', error.response?.status, error.response?.data);
            }
        }
    };

    const deleteBookNotFound = async () => {
        const id = 9999;
        try {
            await http.delete(`/books/${id}`);
            console.log('[FAIL] deleteBookNotFound - Expected 404, but got success');
        } catch (error) {
            if (error.response && error.response.status === 404 && error.response.data.message === "Book not found") {
                console.log('[PASS] deleteBookNotFound');
            } else {
                console.log('[FAIL] deleteBookNotFound - Unexpected error response:', error.response?.status, error.response?.data);
            }
        }
    };

    return {
        noBookFound,
        bookList,
        bookCreate,
        deleteBook,
        updateBook,
        getBookNotFound,
        deleteBookNotFound
    }
}


(async () => {
    console.log("--- Running Tests ---");
    const bookValidator = validateBookList();
    await bookValidator.noBookFound();
    const createdBook = await bookValidator.bookCreate();
    if (!createdBook) {
        console.log("[STOP] Book creation failed, stopping further tests.");
        return; 
    }
    await bookValidator.bookList();
    await bookValidator.updateBook(createdBook.id, "Center of the Earth (Revised)");
    await bookValidator.getBookNotFound(); 
    await bookValidator.deleteBook(createdBook.id);
    await bookValidator.deleteBookNotFound(); 
    await bookValidator.noBookFound(); 
    console.log("--- Tests Finished ---");
})()