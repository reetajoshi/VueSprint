# Book API Project

This project implements a simple RESTful API for managing a collection of books, built with Node.js and Express.js. It supports basic CRUD (Create, Read, Update, Delete) operations and includes essential middleware for logging, authentication, and error handling.

## Project Structure

-   `index.js`: The main server entry point. It sets up the Express application, applies global middleware, and imports the API routes.
-   `books_appi/server.js`: Contains the core API logic for the `/books` resource, defining all the GET, POST, PUT, and DELETE routes. It also manages the in-memory book data.
-   `books_appi/client.js`: An automated test client script that interacts with the API endpoints to verify their functionality, status codes, and responses.
-   `package.json`: Defines project metadata and lists all Node.js dependencies.

## Features

-   **RESTful API Endpoints:**
    -   `GET /books`: Retrieves a list of all books stored in memory. Returns `{ message: "no books found" }` if the list is empty.
    -   `GET /books/:id`: Retrieves the details of a specific book by its unique `id`. Returns `404 Not Found` if the book does not exist.
    -   `POST /books`: Creates a new book. Requires `title`, `author`, and `isbn` in the request body. Returns `201 Created` with the new book object on success, or `400 Bad Request` if required fields are missing.
    -   `PUT /books/:id`: Updates an existing book's details. Can update `title`, `author`, and/or `isbn`. Returns `404 Not Found` if the book does not exist.
    -   `DELETE /books/:id`: Deletes a book by its `id`. Returns `200 OK` with a "deleted" message on success, or `404 Not Found` if the book does not exist.

-   **In-Memory Data Storage:**
    -   Books are stored in a simple JavaScript array (`books = []`) in `books_appi/server.js`.
    -   IDs are auto-incremented using a counter (`nextId`).
    -   **Important:** Data is ephemeral; it will be lost if the server restarts. This is by design for this assignment.

-   **Middleware Implementations:**
    -   **Logging Middleware:** Logs every incoming HTTP request (`method`, `URL`, `timestamp`) to the server console for monitoring.
    -   **Authentication Middleware:** Protects all API routes. Requires an `Authorization` header with a specific valid token (`"your_secret_api_key_123"`) to access the API. Returns `401 Unauthorized` for invalid or missing tokens.
    -   **Error Handling Middleware:** Catches any unexpected errors that occur during request processing, logs them to the server console, and sends a generic `500 Internal Server Error` response to the client to prevent application crashes.

## Setup Instructions

To get this project running on your local machine, follow these steps:

1.  **Clone or Download:**
    -   If you're using Git, clone the repository to your local machine.
    -   Alternatively, download the project folder as a ZIP and extract it.

2.  **Navigate to the Project Root:**
    -   Open your terminal (Command Prompt/PowerShell on Windows, Terminal on macOS/Linux).
    -   Navigate to the `01_Introduction` directory using the `cd` command:
        ```bash
        cd path/to/your/01_Introduction
        ```

3.  **Install Dependencies:**
    -   Install the required Node.js packages for the server:
        ```bash
        npm install express
        ```
    -   Navigate into the `books_appi` directory to install client-side dependencies:
        ```bash
        cd books_appi
        npm install axios
        ```
    -   Navigate back to the project root (`01_Introduction`):
        ```bash
        cd ..
        ```

## How to Run the Application

You will need two separate terminal windows/tabs to run the server and the client tests concurrently.

1.  **Start the Server:**
    -   In your **first terminal** (ensure you are in the `01_Introduction` directory), run:
        ```bash
        node index.js
        ```
    -   You should see output indicating the server is running on `http://localhost:3000`:
        ```
        Server is running on http://localhost:3000
        Express server is ready to receive requests!
        ```
    -   **Keep this terminal open and running.**

2.  **Run the Client Tests:**
    -   Open a **second terminal** window/tab.
    -   Navigate to the `books_appi` directory:
        ```bash
        cd books_appi
        ```
    -   Execute the client test script:
        ```bash
        node client.js
        ```
    -   You should see a series of `[PASS]` messages in this terminal, indicating that all API functionalities are working correctly:
        ```
        --- Running Tests ---
        [PASS] noBookFound
        [PASS] bookCreate
        [PASS] bookList
        [PASS] updateBook
        [PASS] getBookNotFound
        [PASS] deleteBook
        [PASS] deleteBookNotFound
        [PASS] noBookFound
        --- Tests Finished ---
        ```
    -   (Optional: Observe the server terminal for logging output as the client runs.)


---