const express = require('express');
const app = express();
const port = 3000;

const bookApiRouter = require('./books_appi/server');

app.use(express.json());

const loggingMiddleware = (req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method}: ${req.url}`);
    next();
};
app.use(loggingMiddleware);

const VALID_AUTH_TOKEN = "your_secret_api_key_123";
const authenticateMiddleware = (req, res, next) => {
    const authToken = req.headers.authorization;
    if (!authToken || authToken !== VALID_AUTH_TOKEN) {
        return res.status(401).json({ message: "Unauthorized: Invalid or missing token." });
    }
    next();
};
app.use(authenticateMiddleware);

app.use('/', bookApiRouter);

const errorHandlingMiddleware = (err, req, res, next) => {
    console.error("An unexpected error occurred:", err.message);
    console.error(err.stack);
    return res.status(500).json({
        message: "Internal Server Error",
        error: err.message
    });
};
app.use(errorHandlingMiddleware);

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
    console.log('Express server is ready to receive requests!');
});
